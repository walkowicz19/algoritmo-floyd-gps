import tkinter as tk
from tkinter import messagebox, simpledialog
import networkx as nx
import matplotlib.pyplot as plt

class CaminhoMinimoApp:
    def _init_(self, root):
        self.root = root
        self.root.title("Algoritmo de Caminho Mínimo - Dijkstra")
        
        self.graph = nx.Graph()

        # Interface
        self.label = tk.Label(root, text="Adicionar Arestas (formato: A B 5):")
        self.label.pack()

        self.entry = tk.Entry(root, width=30)
        self.entry.pack()

        self.add_button = tk.Button(root, text="Adicionar Aresta", command=self.add_edge)
        self.add_button.pack()

        self.draw_button = tk.Button(root, text="Visualizar Grafo", command=self.draw_graph)
        self.draw_button.pack()

        self.calc_button = tk.Button(root, text="Calcular Caminho Mínimo", command=self.calculate_path)
        self.calc_button.pack()

    def add_edge(self):
        input_str = self.entry.get()
        try:
            u, v, w = input_str.split()
            self.graph.add_edge(u, v, weight=float(w))
            messagebox.showinfo("Sucesso", f"Aresta {u}-{v} com peso {w} adicionada.")
            self.entry.delete(0, tk.END)
        except:
            messagebox.showerror("Erro", "Formato inválido. Use: A B 5")

    def draw_graph(self):
        pos = nx.spring_layout(self.graph)
        weights = nx.get_edge_attributes(self.graph, 'weight')

        nx.draw(self.graph, pos, with_labels=True, node_color='lightblue', node_size=500)
        nx.draw_networkx_edge_labels(self.graph, pos, edge_labels=weights)
        plt.title("Grafo Atual")
        plt.show()

    def calculate_path(self):
        if len(self.graph.nodes) == 0:
            messagebox.showerror("Erro", "Adicione arestas antes de calcular o caminho.")
            return

        origem = simpledialog.askstring("Origem", "Digite o nó de origem:")
        destino = simpledialog.askstring("Destino", "Digite o nó de destino:")

        if origem not in self.graph.nodes or destino not in self.graph.nodes:
            messagebox.showerror("Erro", "Nó de origem ou destino não encontrado no grafo.")
            return

        try:
            path = nx.dijkstra_path(self.graph, origem, destino)
            cost = nx.dijkstra_path_length(self.graph, origem, destino)
            messagebox.showinfo("Caminho Mínimo", f"Caminho: {' -> '.join(path)}\nCusto total: {cost}")
        except nx.NetworkXNoPath:
            messagebox.showerror("Erro", f"Não existe caminho entre {origem} e {destino}.")

if _name_ == "_main_":
    root = tk.Tk()
    app = CaminhoMinimoApp(root)
    root.mainloop()